# @egdev/tokens

Tokens de EGDEV Foundation.

| Archivo | Qué es |
|---|---|
| `src/tokens.json` | Fuente (exportado del artefacto de Claude Design) |
| `src/tokens.css` | Variables CSS en `:root`, para apps sin Tailwind y para los lienzos de Claude Design |
| `src/theme.css` | Tema de Tailwind v4 generado con `pnpm build` (`scripts/build-theme.mjs`) |

La escala de espaciado de Tailwind (4 px) coincide con `--space-*`, así que `p-4` = `var(--space-4)`.

Pendiente: generar `tokens.css` directamente desde `tokens.json` (hoy está escrito a partir de él).
