import { cn } from '@/lib/cn';
import { type SurfaceProps, surfaceVariants } from './types';

type UseSurfaceReturn = Omit<SurfaceProps, 'tone' | 'padding' | 'radius'> & {
  asChild: boolean;
  className: string;
};

export const useSurface = ({
  tone = 'default',
  padding = 'md',
  radius = 'xl',
  asChild = false,
  className,
  ...rest
}: SurfaceProps): UseSurfaceReturn => ({
  ...rest,
  asChild,
  className: cn(surfaceVariants({ tone, padding, radius }), className)
});
