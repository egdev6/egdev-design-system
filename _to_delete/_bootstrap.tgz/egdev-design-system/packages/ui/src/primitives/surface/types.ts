import { cva, type VariantProps } from 'class-variance-authority';
import type { ComponentProps } from 'react';

export const surfaceVariants = cva('eg-surface', {
  variants: {
    /** Fondo y borde. `glass` es el panel flotante (antes ModuleCard --glass, Stat --glass y la tira de Gauge). */
    tone: {
      default: '',
      glass: 'eg-surface--glass',
      brand: 'eg-surface--brand',
      ghost: 'eg-surface--ghost'
    },
    padding: {
      none: 'eg-surface--pad-none',
      sm: 'eg-surface--pad-sm',
      md: '',
      lg: 'eg-surface--pad-lg'
    },
    radius: {
      md: 'eg-surface--radius-md',
      lg: 'eg-surface--radius-lg',
      xl: '',
      full: 'eg-surface--radius-full'
    }
  },
  defaultVariants: { tone: 'default', padding: 'md', radius: 'xl' }
});

export type SurfaceProps = ComponentProps<'div'> &
  VariantProps<typeof surfaceVariants> & {
    /**
     * Renderiza el hijo en lugar de un `div` (Radix Slot): `<Surface asChild><section/></Surface>`.
     * @default false
     */
    asChild?: boolean;
    /**
     * @control select
     * @default 'default'
     */
    tone?: 'default' | 'glass' | 'brand' | 'ghost';
    /**
     * @control select
     * @default 'md'
     */
    padding?: 'none' | 'sm' | 'md' | 'lg';
    /**
     * @control select
     * @default 'xl'
     */
    radius?: 'md' | 'lg' | 'xl' | 'full';
  };
