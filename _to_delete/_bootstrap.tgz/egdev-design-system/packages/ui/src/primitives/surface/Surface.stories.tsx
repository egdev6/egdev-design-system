import type { Meta, StoryObj } from '@storybook/react';
import { Surface } from './Surface';

/**
 * ## Descripción
 * Caja con fondo, borde y radio del sistema. Es la base de ModuleCard, ListItem, el panel de Quorb
 * y cualquier sección de ajustes: nada debería repetir `background + border + radius` a mano.
 *
 * ## Radix
 * Usa `Slot` para `asChild`, así puede ser un `section`, un `article` o un `li` sin envolturas extra.
 */
const meta: Meta<typeof Surface> = {
  title: 'Primitives/Surface',
  component: Surface,
  tags: ['autodocs'],
  args: { children: 'Contenido de la superficie' }
};
export default meta;

type Story = StoryObj<typeof Surface>;

/** Superficie por defecto: fondo surface, borde y radio xl. */
export const Default: Story = {};

/** Los cuatro tonos: el cristal sustituye a los `--glass` sueltos de antes. */
export const Tones: Story = {
  render: () => (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16 }}>
      <Surface>default</Surface>
      <Surface tone='glass'>glass</Surface>
      <Surface tone='brand'>brand</Surface>
      <Surface tone='ghost'>ghost</Surface>
    </div>
  )
};
