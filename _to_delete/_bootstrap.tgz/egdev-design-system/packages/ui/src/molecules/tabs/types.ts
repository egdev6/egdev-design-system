import { cva, type VariantProps } from 'class-variance-authority';
import type { ReactNode } from 'react';

export const tabsListVariants = cva('eg-tabs', {
  variants: { size: { md: '', sm: 'eg-tabs--sm' } },
  defaultVariants: { size: 'md' }
});

export type TabItem = {
  value: string;
  label: ReactNode;
  /** Contador junto a la etiqueta. */
  count?: number;
  /** El contador va en rojo (errores, fallos). */
  danger?: boolean;
  disabled?: boolean;
  /** Panel asociado. Si ningún item lo tiene, Tabs funciona como selector (24 h · 7 d · 30 d). */
  content?: ReactNode;
};

export type TabsProps = VariantProps<typeof tabsListVariants> & {
  /** Nombre accesible de la lista de pestañas. */
  label: string;
  items: TabItem[];
  /** Pestaña inicial (no controlado). Por defecto, la primera. */
  defaultValue?: string;
  /** Pestaña activa (controlado). */
  value?: string;
  onValueChange?: (value: string) => void;
  /**
   * @control select
   * @default 'md'
   */
  size?: 'md' | 'sm';
  className?: string;
};
